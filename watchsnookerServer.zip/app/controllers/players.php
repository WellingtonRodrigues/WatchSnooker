<?php

class Players extends Controller{
	public function index(){
		$this->view('players/index');
	}
}