<?php

class Newsletter extends Controller{
	public function index(){
		$this->view('common/uc');
	}
}