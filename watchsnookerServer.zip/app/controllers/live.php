<?php

class Live extends Controller{
	public function index(){
		$this->view('common/uc');
	}
}