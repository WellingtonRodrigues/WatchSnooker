<?php

class Ideas extends Controller{
	public function index(){
		$this->view('ideas/index');
	}
}