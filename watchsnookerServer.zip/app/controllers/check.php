<?php

class Check extends Controller{
	public function index(){
		$this->view('check/index');
	}
}