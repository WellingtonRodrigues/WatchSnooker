<?php

class Rules extends Controller{
	public function index(){
		$this->view('common/uc');
	}
}