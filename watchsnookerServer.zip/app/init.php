<?php

define("BASE_URL", "http://localhost/watchsnooker/public");

require_once '../app/core/App.php';
require_once '../app/core/Controller.php';